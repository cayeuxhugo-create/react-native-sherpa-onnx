# Modules Guardian — cœur vocal v2

Deux profils : `DISTANT` et `NOISY`.

Lire `modules/guardian-native-protection/MOTEUR_VOCAL.md` pour intégrer le
module, sélectionner le profil et réaliser les essais sur téléphone.

`VALIDATION.md` distingue les tests exécutés des vérifications Android
encore nécessaires. `CHANGEMENTS.patch` permet de relire les modifications
textuelles ; les modèles ONNX sont livrés séparément dans les assets.

L'archive ne contient pas d'APK, ni le projet Expo principal, ni l'AAR
Sherpa personnalisé, ni les modèles Qwen. Ces éléments existants sont
à conserver dans votre application.
