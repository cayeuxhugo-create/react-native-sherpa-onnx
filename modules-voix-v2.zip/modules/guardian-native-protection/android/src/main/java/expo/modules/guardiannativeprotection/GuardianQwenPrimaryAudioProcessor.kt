package expo.modules.guardiannativeprotection

import android.content.Context
import android.os.SystemClock
import android.util.Log
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/** One capture, one ordered input, one neural VAD, one Qwen decoder.
 * Neither acoustic level labels nor ASR output can declare speech present. */
internal class GuardianQwenPrimaryAudioProcessor(
    context: Context,
    private val decoder: GuardianQwenProgressiveDecoder,
    private val listener: Listener,
    private val profile: GuardianVoiceProfile = GuardianVoiceProfile.DISTANT,
) : GuardianAudioEngine.AudioProcessor {
    interface Listener {
        fun onSpeechStarted()
        fun onSpeechEnded()
        fun onWarning(message: String)
    }

    // Load before capture. Missing/incompatible VAD must fail explicitly, never
    // silently fall back to RMS-only admission (the original hallucination bug).
    private val vad = GuardianNeuralVad(context)
    private val closed = AtomicBoolean(false)
    private val discontinuity = AtomicBoolean(false)
    private val pendingTasks = AtomicInteger(0)
    private val worker = Executors.newSingleThreadScheduledExecutor { task ->
        Thread(task, "Guardian-Speech-Input").apply { isDaemon = true }
    }
    private var previousKey: GuardianVoiceInputRouter.Key? = null
    private var warningAtMs = Long.MIN_VALUE
    private var truthFrames = 0L
    private var enhancedFrames = 0L
    private var lastMetricsAtMs = 0L
    private val segmenter = GuardianSpeechSegmenter(object : GuardianSpeechSegmenter.Sink {
        override fun onSpeechStarted() = listener.onSpeechStarted()
        override fun onSpeechEnded() = listener.onSpeechEnded()
        override fun onWindow(id: Long, pcm: FloatArray, final: Boolean, reason: String) {
            if (closed.get()) return
            val evidence = GuardianQwenProgressiveDecoder.AcousticEvidence.NEURAL_CONFIRMED
            val accepted = if (final) {
                decoder.offerFinal(id, pcm, reason, evidence)
            } else {
                decoder.offerPartial(id, pcm, evidence)
            }
            if (!accepted) warn("Fenêtre Qwen refusée : final=$final, segment=$id")
        }
    })
    private val router = GuardianVoiceInputRouter(
        noisy = profile == GuardianVoiceProfile.NOISY,
        emit = { frame, pcm, enhanced ->
            val previous = previousKey
            if (previous != null && (frame.key.sequence != previous.sequence + 1 ||
                frame.key.capturedAtNanos <= previous.capturedAtNanos)) {
                resetSpeech()
                warn("Discontinuité audio : segment abandonné, VAD réinitialisée")
            }
            previousKey = frame.key
            if (enhanced) enhancedFrames++ else truthFrames++
            segmenter.accept(pcm, vad.isSpeech(pcm))
            val now = SystemClock.elapsedRealtime()
            if (now - lastMetricsAtMs >= 5_000L) {
                Log.i(TAG, "VOICE_INPUT profile=$profile truthFrames=$truthFrames gtcrnFrames=$enhancedFrames")
                lastMetricsAtMs = now
            }
        },
        warning = { warn(it) },
    )

    init {
        worker.scheduleAtFixedRate({ guarded { router.drain(SystemClock.elapsedRealtime()) } },
            20L, 20L, TimeUnit.MILLISECONDS)
    }

    override fun onAudioFrame(frame: GuardianAudioEngine.AudioFrame) {
        if (closed.get()) return
        if (frame.sampleRateHz != 16_000) {
            discontinuity.set(true)
            return
        }
        val count = frame.sampleCount.coerceIn(0, frame.samples.size)
        if (count == 0) return
        // The engine reuses its arrays immediately after this callback.
        val input = GuardianVoiceInputRouter.Input(
            key = GuardianVoiceInputRouter.Key(frame.sequenceNumber, frame.capturedAtElapsedRealtimeNanos),
            pcm = frame.samples.copyOf(count),
            gain = frame.adaptiveGain,
            enhancementExpected = frame.enhancementExpected,
            queuedAtMs = SystemClock.elapsedRealtime(),
        )
        enqueue { router.primary(input, SystemClock.elapsedRealtime()) }
    }

    override fun onEnhancedAudioFrame(frame: GuardianAudioEngine.EnhancedAudioFrame) {
        if (closed.get() || profile != GuardianVoiceProfile.NOISY || frame.source != "GTCRN") return
        val count = frame.sampleCount.coerceIn(0, frame.samples.size)
        if (count == 0) return
        val key = GuardianVoiceInputRouter.Key(frame.sequenceNumber, frame.capturedAtElapsedRealtimeNanos)
        val pcm = frame.samples.copyOf(count)
        enqueue { router.enhanced(key, pcm, SystemClock.elapsedRealtime()) }
    }

    private fun enqueue(action: () -> Unit) {
        if (pendingTasks.incrementAndGet() > 32) {
            pendingTasks.decrementAndGet()
            discontinuity.set(true)
            return
        }
        try {
            worker.execute {
                try { guarded(action) } finally { pendingTasks.decrementAndGet() }
            }
        } catch (_: RejectedExecutionException) {
            pendingTasks.decrementAndGet()
        }
    }

    private fun guarded(action: () -> Unit) {
        if (closed.get()) return
        try {
            if (discontinuity.getAndSet(false)) {
                router.reset()
                previousKey = null
                resetSpeech()
                warn("Saturation entrée audio : état réinitialisé")
            }
            action()
        } catch (error: Throwable) {
            Log.e(TAG, "Erreur du cœur vocal, aucune hypothèse publiée pour cette frame", error)
            discontinuity.set(true)
            warn("Erreur validation vocale : ${error.javaClass.simpleName}")
        }
    }

    private fun resetSpeech() {
        decoder.reset()
        vad.reset()
        segmenter.reset()
    }

    private fun warn(message: String) {
        val now = SystemClock.elapsedRealtime()
        if (warningAtMs == Long.MIN_VALUE || now - warningAtMs >= 5_000L) {
            warningAtMs = now
            listener.onWarning(message)
        }
    }

    fun close() {
        if (!closed.compareAndSet(false, true)) return
        decoder.close()
        // Same worker as VAD inference: no native release during a VAD call.
        worker.execute {
            try {
                router.reset()
                vad.close()
            } finally { worker.shutdownNow() }
        }
    }

    companion object { private const val TAG = "GuardianSpeechInput" }
}
