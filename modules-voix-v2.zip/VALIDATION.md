# Vérifications effectuées

- 14 tests Kotlin du cœur : bruit déclaré non vocal, audio faible admis,
  pré-roll, fin sur silence, chevauchement des segments, réinitialisation,
  PCM invalide, profils, alignement GTCRN, retard, erreur d'identité/taille,
  saturation et absence de duplication.
- 4 tests de concurrence du véritable ordonnanceur Qwen, avec un décodeur
  de substitution contrôlé : arrêt et réinitialisation pendant un partial
  ou un final en cours. Aucun résultat périmé livré dans ces scénarios.
- Adaptateur Kotlin compilé contre le fichier VAD officiel Sherpa 1.13.8
  vérifié par SHA-256. Framework Android et Qwen remplacés par des contrats
  de test : ce n'est pas une compilation APK.
- Types TypeScript du module compilés en mode strict avec contrat Expo de
  substitution. L'application Expo principale n'est pas fournie.
- Modèles Silero et GTCRN réellement exécutés avec Sherpa 1.13.8 sur Linux.
  Sur 10 s de silence, 10 s de bruit blanc RMS 0,003, 10 s de bruit blanc
  RMS 0,03 et 10 s de sinus 100 Hz : zéro frame détectée vocale.
- Parole anglaise de référence de 6,625 s : présence vocale détectée sur
  l'original, sa version atténuée ×0,1, sa version bruitée et la combinaison
  atténuée + bruit. GTCRN produit un signal fini détecté vocal pour cette
  dernière ; sa sortie pour le bruit blanc testé n'est pas détectée vocale.

Le fichier de parole utilisé est `0-en.wav` du dépôt de développement
react-native-sherpa-onnx. Il n'est pas inclus dans cette livraison. Le script
accepte un WAV mono PCM16 à 16 kHz fourni en argument. Les résultats chiffrés
sont dans `modules/guardian-native-protection/tests/results/`.

## Non exécuté / non établi

Pas de compilation du projet Expo complet, pas de vérification de votre AAR
`gv3895-2`, pas d'exécution JNI Android, pas de transcription Qwen réelle,
pas d'évaluation française et pas de mesure à 5 mètres ou en bruit réel.
Les tests de présence vocale ne prouvent pas une amélioration de l'exactitude
des mots. Des faux positifs restent possibles sur d'autres bruits.
