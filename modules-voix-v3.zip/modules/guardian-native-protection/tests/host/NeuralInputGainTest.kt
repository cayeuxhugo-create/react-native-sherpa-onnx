package expo.modules.guardiannativeprotection
import kotlin.math.abs
fun neuralInputGainTests() {
    val weak = floatArrayOf(0.001f, -0.002f, 0f)
    val copy = weak.copyOf()
    check(GuardianNeuralInputGain.forVad(weak).contentEquals(floatArrayOf(0.004f,-0.008f,0f)))
    check(weak.contentEquals(copy))
    val loud = floatArrayOf(0.6f,-0.7f)
    check(GuardianNeuralInputGain.forVad(loud).all { abs(it) <= 0.80001f })
    check(GuardianNeuralInputGain.forVad(floatArrayOf(0.9f))[0] == 0.9f)
    check(runCatching { GuardianNeuralInputGain.forVad(floatArrayOf(Float.NaN)) }.isFailure)
    println("PASS VAD model gain is bounded, preserves the source and never attenuates loud audio")
    val leveler = GuardianGtcrnLeveler(10)
    val a = floatArrayOf(0.01f,-0.02f,0.03f)
    val b = floatArrayOf(0.4f,-0.4f,0.1f)
    val originalA = a.copyOf(); val originalB = b.copyOf()
    leveler.prepareInPlace(a); leveler.prepareInPlace(b)
    check(a.contentEquals(FloatArray(3) { originalA[it]*6f }))
    check(b.contentEquals(FloatArray(3) { originalB[it]*2f }))
    val first = a.copyOfRange(0,2)
    leveler.restoreInPlace(first)
    val rest = floatArrayOf(a[2], b[0], b[1], b[2])
    leveler.restoreInPlace(rest)
    val joined = first + rest
    check(joined.zip(originalA+originalB).all { abs(it.first-it.second)<1e-7f })
    println("PASS delayed GTCRN output uses the matching input gain across partial output boundaries")
    check(runCatching { leveler.restoreInPlace(floatArrayOf(1f)) }.isFailure)
    leveler.prepareInPlace(FloatArray(10));check(runCatching { leveler.prepareInPlace(FloatArray(1)) }.isFailure)
    leveler.reset()
    val after = floatArrayOf(0.1f);leveler.prepareInPlace(after);leveler.restoreInPlace(after)
    check(abs(after[0]-0.1f)<1e-7f)
    println("PASS gain history is bounded, rejects unmatched output and resets across sessions")
    val evidence = GuardianSpeechEvidence()
    repeat(1000) { check(!evidence.accept(false, true, 800)) }
    check(evidence.accept(true, false, 800))
    repeat(12) { check(evidence.accept(false, true, 800)) }
    check(!evidence.accept(false, true, 800))
    check(!evidence.accept(false, false, 800))
    check(evidence.accept(true, false, 800))
    evidence.reset()
    check(!evidence.accept(false, true, 800))
    println("PASS denoiser speech cannot open a segment and can only support 600 ms after primary confirmation")

}
