package expo.modules.guardiannativeprotection

/** Peak-bounded model conditioning. A gain is never evidence of speech. */
internal object GuardianNeuralInputGain {
    fun gain(pcm: FloatArray, maximum: Float): Float {
        require(maximum >= 1f && maximum.isFinite())
        require(pcm.all { it.isFinite() })
        val peak = pcm.maxOfOrNull { kotlin.math.abs(it) } ?: 0f
        return if (peak == 0f) maximum else minOf(maximum, 0.8f / peak).coerceAtLeast(1f)
    }

    fun forVad(pcm: FloatArray): FloatArray {
        val gain = gain(pcm, 4f)
        return FloatArray(pcm.size) { pcm[it] * gain }
    }
}

/** Match compensation to the INPUT samples, including delayed/partial native
 * outputs. Never divide an old output by the gain of the newest input block. */
internal class GuardianGtcrnLeveler(private val capacity: Int = 16000) {
    private data class Block(val gain: Float, var remaining: Int)
    private val pending = ArrayDeque<Block>()
    private var samples = 0

    fun prepareInPlace(pcm: FloatArray) {
        require(pcm.size <= capacity - samples) { "GTCRN gain history overflow" }
        if (pcm.isEmpty()) return
        val gain = GuardianNeuralInputGain.gain(pcm, 6f)
        for (i in pcm.indices) pcm[i] *= gain
        pending.addLast(Block(gain, pcm.size))
        samples += pcm.size
    }

    fun restoreInPlace(pcm: FloatArray) {
        require(pcm.size <= samples) { "GTCRN output exceeds gain history" }
        require(pcm.all { it.isFinite() }) { "GTCRN non-finite output" }
        var offset = 0
        while (offset < pcm.size) {
            val block = pending.first()
            val count = minOf(pcm.size - offset, block.remaining)
            for (i in offset until offset + count) pcm[i] /= block.gain
            offset += count
            block.remaining -= count
            samples -= count
            if (block.remaining == 0) pending.removeFirst()
        }
    }

    fun reset() { pending.clear(); samples = 0 }
}

/** Only the unmodified primary neural view may open speech. The denoised
 * view can bridge a short dropout after confirmation, never admit noise alone. */
internal class GuardianSpeechEvidence(private val supportSamples: Int = 16000 * 600 / 1000) {
    private var sincePrimary: Long? = null
    fun accept(primarySpeech: Boolean, enhancedSpeech: Boolean, samples: Int): Boolean {
        require(samples >= 0)
        sincePrimary = if (primarySpeech) 0 else sincePrimary?.let {
            (it + samples).coerceAtMost(supportSamples.toLong() + 1)
        }
        return primarySpeech || (enhancedSpeech && sincePrimary?.let { it <= supportSamples } == true)
    }
    fun reset() { sincePrimary = null }
}
