# Vérification de la variante diagnostic

- 18 tests du cœur et de concurrence toujours réussis.
- 4 tests supplémentaires des logs : désactivés par défaut, JSON borné
  et échappé, erreurs du récepteur isolées, RMS/dBFS et silence.
- JSON généré analysé avec un parseur Python indépendant : guillemets,
  antislash, saut de ligne, tabulation, emoji, NaN et longueur 512 validés.
- Nouvel adaptateur compilé contre l'API Sherpa VAD officielle 1.13.8, avec
  substituts Android/Qwen. Types TypeScript vérifiés avec contrat Expo de test.
- Script PowerShell analysé par le parseur de PowerShell 7.4.6. Exécution
  complète avec adb simulé : 8 cas et 16 marqueurs, métadonnées et ZIP valides,
  vieux WAV exclu, refus simulé de adb pull puis copie run-as binaire identique.
  Le simulateur fournit des données de test, pas des mesures d'un téléphone.
- Sources de capture, segmentation, Silero, configuration du modèle Qwen et
  traitement GTCRN identiques octet pour octet à la version v2 livrée.

Pas de compilation APK complète et pas de téléphone connecté ici.
L'instrumentation ajoute une charge de journalisation seulement si activée.
Les textes sont inclus, pas les échantillons audio dans logcat. Les WAV
existants sont copiés uniquement sur demande via -IncludeWav.

Les résultats de reconnaissance français mesurés ensuite dans le cloud ne
prouvent pas la robustesse générale : la v2 échoue encore dans certains
bruits plus marqués. Ce kit sert à étudier le vrai téléphone.
