# Guardian Voice v2 — variante diagnostic

Commencer par `modules/guardian-native-protection/diagnostics/LIRE-MOI.md`.

Cette archive conserve les réglages de reconnaissance de la v2 et ajoute
les logs opt-in (`voiceDiagnosticsEnabled`) et un collecteur PowerShell
pour les logs et les WAV stéréo existants. Elle exige une reconstruction
native Android pour les nouveaux logs. Le collecteur peut déjà récupérer
les anciens logs et les WAV disponibles sans cette reconstruction.

Les WAV bruts ne sont créés que par le diagnostic multi-micro déjà présent
dans votre code. Le collecteur ne change pas la capture ni ses overrides.

Le projet Expo principal, l'AAR Sherpa personnalisé, les modèles Qwen et
la validation sur téléphone restent nécessaires.
