package android.content.res
class AssetManager { fun open(path: String): java.io.InputStream = java.io.ByteArrayInputStream(byteArrayOf(1)) }
