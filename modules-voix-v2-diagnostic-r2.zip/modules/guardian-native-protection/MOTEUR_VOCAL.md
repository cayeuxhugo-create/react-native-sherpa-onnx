# Cœur vocal reconstruit — version à valider sur Android

Le problème visé est l'apparition de mots en l'absence de parole. L'ancien
chemin admettait la parole à partir de seuils RMS/SNR et ignorait la sortie
GTCRN pour Qwen. Cette version sépare la présence vocale, le traitement du
bruit, la segmentation et la transcription.

| Profil | Entrée de reconnaissance | Usage à vérifier |
| --- | --- | --- |
| `DISTANT` (défaut) | Voie principale existante, gain et limiteur conservés | Voix faible/lointaine dans le calme |
| `NOISY` | Sortie GTCRN alignée sur la même capture, puis gain existant | Voix dans un environnement bruité, y compris voix distante |

Les deux profils passent par Silero VAD avant Qwen. Les étiquettes acoustiques
`CLEAR_SPEECH` et `Far Voice` ne suffisent plus à autoriser la transcription.
Leur rôle historique dans la capture et le gain reste présent. Aucune seconde
capture micro et aucun second décodeur Qwen ne sont ajoutés.

```mermaid
flowchart LR
  A[Capture existante] --> B{Profil}
  B -->|DISTANT| C[Voie principale + gain]
  B -->|NOISY| D[GTCRN + gain]
  C --> V[Silero : présence vocale]
  D --> V
  V --> S[Pré-roll et segmentation]
  S --> Q[Qwen : transcription]
  Q --> P[Timeline et logique Guardian existantes]
```

## Intégration

1. Conserver une copie de votre module actuel. Fusionner le dossier
   `modules/guardian-native-protection` de cette archive dans l'application Expo.
   Les anciens dossiers `android/build` ne sont pas fournis : ce sont des sorties
   de compilation, pas des sources.
2. Conserver l'AAR Sherpa, les modèles Qwen et la configuration Firebase de
   l'application principale. Le module continue à référencer
   `android/app/libs/sherpa-onnx-1.13.8-gv3895-2.aar`. Ce fichier personnalisé
   n'était pas dans l'archive initiale ; son contenu n'a pas été vérifié ici.
3. Les modèles `silero_vad.onnx` et `gtcrn_simple.onnx`, avec leurs licences,
   sont inclus dans `android/src/main/assets`. Vérifier qu'aucun asset de
   l'application principale n'écrase ces fichiers avec une autre version.
4. Reconstruire l'application native Android avec sa commande Expo/Gradle
   habituelle. Un simple rechargement JavaScript n'applique pas ce changement.

Choisir le profil dans la configuration existante, avant de démarrer la
protection (identité, permissions et autres paramètres inchangés) :

```ts
await GuardianNativeProtection.configureProtection({
  ...configurationExistante,
  voiceEnabled: true,
  voiceProfile: 'DISTANT', // ou 'NOISY'
});
await GuardianNativeProtection.startProtection();
```

Un changement de profil s'applique au prochain démarrage complet de la
protection. Si elle tourne déjà, utiliser l'arrêt existant et attendre son
arrêt effectif avant de configurer/redémarrer. Le choix est persisté dans
DataStore (`voice_profile`) et renvoyé par `getNativeConfig()`.

Le profil `NOISY` est un choix explicite : il charge GTCRN même si le profil
matériel historique le déconseillait. Sur un téléphone lent, surveiller les
compteurs et les replis ci-dessous ; aucune performance temps réel n'est
présumée. Les protections de charge et de panne restent actives.

## Comportement du cœur

- Silero : 16 kHz, seuil 0,5, durée minimale de parole/silence 128 ms,
  un thread. Ce sont des réglages de départ, pas une calibration à 5 mètres.
- Pré-roll 400 ms pour conserver l'attaque de la phrase.
- Hypothèses partielles espacées d'au moins une seconde d'audio vocal.
- Fin après 600 ms non vocaux, avec seulement 200 ms de queue conservés.
- Segments techniques de 8 s, chevauchement acoustique 400 ms pour éviter
  de couper un mot sans contexte. La timeline existante rapproche les mots
  chevauchants ; une répétition d'un seul mot peut rester ambiguë sans
  timestamps acoustiques Qwen.
- En bruit : jointure GTCRN par numéro de frame ET timestamp de capture.
  Une sortie manquante/invalide ne bloque pas la capture : repli sur l'original
  après 200 ms, avec journal et comptage de la voie utilisée. Une sortie
  tardive n'est jamais ajoutée une seconde fois.
- Une saturation ou une discontinuité réinitialise le VAD, abandonne le
  segment incomplet et invalide les résultats Qwen encore en vol.
- L'absence du modèle VAD provoque un échec vocal explicite ; aucun repli
  silencieux vers une admission fondée seulement sur le volume.

Les logs `GuardianSpeechInput` indiquent `profile`, `truthFrames` et
`gtcrnFrames`. En `NOISY`, vérifier que `gtcrnFrames` progresse réellement.
Les avertissements GTCRN sont limités à un toutes les cinq secondes.

## Vérifications reproductibles

Avec Kotlin et Java installés :

```sh
bash modules/guardian-native-protection/tests/run-host-tests.sh
# Compilation des nouveaux composants contre l'API VAD officielle 1.13.8 :
bash modules/guardian-native-protection/tests/check-reference-api.sh
# Mieux : vérifier les signatures de votre propre AAR :
SHERPA_AAR=/chemin/sherpa-onnx-1.13.8-gv3895-2.aar \
  bash modules/guardian-native-protection/tests/check-reference-api.sh
```

La compilation de référence utilise des substituts pour Android et Qwen.
Elle ne remplace ni une compilation APK ni un test JNI Android. Les tests
hôte utilisent le vrai code de segmentation, routage et ordonnanceur ;
le décodeur natif est remplacé par un double contrôlé pour les courses.

Pour les modèles, dans un environnement Python dédié, installer
`numpy` et `sherpa-onnx==1.13.8`, puis :

```sh
python modules/guardian-native-protection/tests/validate_models.py \
  --speech-wav /chemin/parole-mono-16khz-pcm16.wav --report resultats.json
```

Le script vérifie les empreintes des deux modèles et utilise le vrai moteur
Sherpa Linux pour Silero et GTCRN. Il teste les bruits synthétiques et une
parole de référence, pas l'exactitude de Qwen.

## Validation indispensable sur téléphone

Comparer les deux profils sur le même téléphone et les mêmes phrases :

1. Sans parole : 60 s de calme, puis 60 s avec le bruit habituel. Compter les
   transcriptions produites ; noter le type de bruit.
2. Parole : à 1 m, 3 m et 5 m, répéter plusieurs phrases connues dans le calme,
   puis avec le même léger bruit. Conserver la référence et la transcription.
3. Mesurer mots incorrects, mots manquants, mots ajoutés et délai d'affichage.
   Vérifier les compteurs GTCRN et les avertissements de saturation.

Une VAD peut encore confondre certains bruits avec de la parole. Elle accepte
également de vraies voix de télévision ou de radio. La portée à 5 mètres,
la transcription française, les accents et les bruits réels ne sont pas
validés par les essais synthétiques fournis.

## Portée de la livraison

Le cœur audio/ASR et son raccordement au service sont modifiés. Les fonctions
GPS, PTI, upload, API cloud, Firebase et logique de décision d'alerte n'ont pas
été réécrites. Qwen reste un modèle offline décodé progressivement, et non
un moteur streaming natif. Le projet Expo complet et l'AAR personnalisé
manquent ici : aucun APK ni test sur téléphone n'a été produit.


## Collecte sur téléphone

Cette variante ajoute uniquement une instrumentation optionnelle. Voir
`diagnostics/LIRE-MOI.md` et `collect-guardian-logs.ps1` pour les logs et
la récupération des WAV stéréo déjà produits par votre code.


## Diagnostic r2

Pour le nouveau protocole avec WAV mono, profils verifies et fichiers de controle
temporaires, suivre `diagnostics/LIRE-MOI.md`. Ces instructions remplacent les
anciennes instructions de collecte stereo. Les algorithmes vocaux sont inchanges.
