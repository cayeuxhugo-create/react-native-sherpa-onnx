package android.util
object Log {
    fun i(tag: String, message: String) = 0
    fun e(tag: String, message: String, error: Throwable) = 0
}
